import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import './App.css';
const LoanForm = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    fullName: "",
    loanAmount: "",
    purpose: "House",
    tenure: "",
  });
  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const validationErrors = {};
    // Validations rules: if valid than navigate to welcome page otherwies 
    // navigate to error page
    
  };

  return (
    <div>
    <h1 className="header">Bank Loan Form</h1>

    {/* Create Loan Form HTML */}
    </div>
  );
};

export default LoanForm;
