// ErrorPage.js

import React from 'react';

const ErrorPage = () => {
    // Error message should be displayed in h1
};

export default ErrorPage;
