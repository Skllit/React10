import axios from "axios";
import {
  getSalesData,
  calculateTotalSales,
  calculateTotalCashSale,
  calculateTotalCreditSale,
  calculateBuyerWithMostSale,
} from "../Main/Reports";

jest.mock("axios");

describe("Sales Utils", () => {
  describe("calculateTotalSales", () => {
    it("should return the correct total sales", () => {
      const sales = [
        { saleTotal: 100 },
        { saleTotal: 200 },
        { saleTotal: 300 },
      ];

      const totalSales = calculateTotalSales(sales);

      expect(totalSales).toBe(600);
    });

    it("should return 0 for empty sales array", () => {
      const sales = [];

      const totalSales = calculateTotalSales(sales);

      expect(totalSales).toBe(0);
    });
  });

  describe("calculateTotalCashSale", () => {
    it("should return the correct total cash sales", () => {
      const sales = [
        { saleTotal: 100, creditCard: false },
        { saleTotal: 200, creditCard: true },
        { saleTotal: 300, creditCard: false },
      ];

      const totalCashSale = calculateTotalCashSale(sales);

      expect(totalCashSale).toBe(400);
    });

    it("should return 0 for no cash sales", () => {
      const sales = [
        { saleTotal: 100, creditCard: true },
        { saleTotal: 200, creditCard: true },
        { saleTotal: 300, creditCard: true },
      ];

      const totalCashSale = calculateTotalCashSale(sales);

      expect(totalCashSale).toBe(0);
    });
  });

  describe("calculateTotalCreditSale", () => {
    it("should return the correct total credit sales", () => {
      const sales = [
        { saleTotal: 100, creditCard: false },
        { saleTotal: 200, creditCard: true },
        { saleTotal: 300, creditCard: true },
      ];

      const totalCreditSale = calculateTotalCreditSale(sales);

      expect(totalCreditSale).toBe(500);
    });

    it("should return 0 for no credit sales", () => {
      const sales = [
        { saleTotal: 100, creditCard: false },
        { saleTotal: 200, creditCard: false },
        { saleTotal: 300, creditCard: false },
      ];

      const totalCreditSale = calculateTotalCreditSale(sales);

      expect(totalCreditSale).toBe(0);
    });
  });

  describe("calculateBuyerWithMostSale", () => {
    it("should return the buyer with the most sales", () => {
      const sales = [
        { buyerName: "Buyer 1", saleTotal: 100 },
        { buyerName: "Buyer 2", saleTotal: 200 },
        { buyerName: "Buyer 3", saleTotal: 300 },
      ];

      const buyer = calculateBuyerWithMostSale(sales);

      expect(buyer).toEqual({ buyerName: "Buyer 3", saleTotal: 300 });
    });


  });
});
