import axios from "axios";

export const getSalesData = async () => {
  let { data } = await axios.get(`/sales.json`);
  return data;
};

export const calculateTotalSales = (sales) => {
 
};

export const calculateTotalCashSale = (sales) => {
 
};

export const calculateTotalCreditSale = (sales) => {
  
};

export const calculateBuyerWithMostSale = (sales) => {
 
  
};
