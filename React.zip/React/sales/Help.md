Project Description:
You are asked to build a Sales Dashboard application using React. In this application a sale data entity consists of three fields; saleTotal, buyerName and creditCard. You will find the data in sales.json file in the public folder.

The application requires four dashboard reports. Implement relevant calculations in src/Main/Reports.js and use them in src/Main/Dashboard.jsx file. 

1. Total Sale Report: Implement calculateTotalSales  in src/Main/Reports.js. You must return the sum of all sales.
2. Total Cash Sale Report: Implement calculateTotalCashSale function in src/Main/Reports.js. You must return the sum of all sales where creditCard attribute is false.
3. Total Credit Card Sale Report: Implement calculateTotalCreditSale function in src/Main/Reports.js. You must return the sum of all sales where creditCard attribute is true.
4. Buyer With Most Sale: Implement calculateBuyerWithMostSale function in src/Main/Reports.js. You must return the buyer with the most saleTotal. Thus, if Loron Chaun is the person with the most purchased items, return Loron Chaun and sum of the purchases he made. Return format must be {"buyerName": "Loron Chaun", "saleTotal": 34000}. The sales.json may or may not contain above names and figures. The above example is just to demonstrate the expected data format. 

Your task is to complete the function defined in the file below:
1. src/Main/Reports.js
2. src/Main/Dashboard.jsx

Notes:
1. It is given that each report has a different implementation, but each function will require the sale data. Use getSalesData function in src/Main/Reports.js to fetch sales data. getSalesData function is already implemented for you. 
2. Do not change file names, class names , method  declarations. 
3. Use Test App & Submit option often so you will be guided by test error messages.

Testing & Submitting your code:



Step 1: Click on the WeCP Projects Button.
Step 2: Click on Start frontend server to start the react server.
Step 3: Click on Open Preview to view the GUI.
Step 4: Click on Test & Submit app button to test your code.
Step 5: You will receive a congratulations message upon successful completion of the task.
