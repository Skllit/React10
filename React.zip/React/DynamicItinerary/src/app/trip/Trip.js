// Trip.js
import React, { useState } from 'react';
import Destination from '../destination/Destination';
import '../../App.css'
const Trip = () => {
  const [destinations, setDestinations] = useState([]);

  // Simulate data fetching on initialization
  React.useEffect(() => {
    // Simulating fetching data from an API  set default desitination a
    const fetchData = async () => {
      
     
    };

    
    // Cleanup function to log when component unmounts
  
  }, []);

  const handleAddDestination = () => {
    // add run time desitination by udating location desitination and id
    
  };

  const handleRemoveDestination = (id) => {
//    remove destination logic here 
  };

  return (
    <div className="trip-container">
    {/* add desitination to add new desitination dynamically  */}
    {/* list down desitination   */}
  </div>
  );
};

export default Trip;
