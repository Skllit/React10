// App.js
import React from 'react';
// import Trip from './trip/Trip';
import Trip from './app/trip/Trip';
function App() {
  return (
    <div className="App">
      <Trip />
    </div>
  );
}

export default App;
