// temperatureFunction.js
export const temperatureFunction = (temperature, format) => {
  // check temprature formate write convertion formula to convert.
  // return temprature to use it in weather component
  
};
