// App.js
import React from 'react';
import WeatherComponent from './app/weather/Weather';
import './App.css'; // You can import your CSS file if you have one

function App() {
  return (
    <WeatherComponent/>
  );
}

export default App;
