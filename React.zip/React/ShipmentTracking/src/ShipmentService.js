import environment from "./environments/environment.ts"
const BASE_URL = environment.apiUrl;
export const getAllShipments = async () => {
  
};

export const getShipmentByTrackingId = async (trackingId) => {
//   get shipment based on tracking id 
};

export const addShipment = async (shipmentData) => {
//   post shipment data on json server
};
