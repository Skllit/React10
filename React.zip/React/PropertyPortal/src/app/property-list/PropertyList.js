import React, { useState } from 'react';
import PropertyDetails from './PropertyDetails';

const PropertyList = () => {
  const [properties, setProperties] = useState([
    { id: 1, name: 'Property 1', location: 'Location 1', price: 100000 },
    { id: 2, name: 'Property 2', location: 'Location 2', price: 150000 },
    { id: 3, name: 'Property 3', location: 'Location 3', price: 200000 }
  ]);

  const handleAddProperty = () => {
//    add new porperty logic
  };

  const handleRemoveProperty = (id) => {
    // remove property
};

  return (
    <div>
      <h1>Property List</h1>
     {/* add property button and list down the properties */}
    </div>
  );
};

export default PropertyList;
