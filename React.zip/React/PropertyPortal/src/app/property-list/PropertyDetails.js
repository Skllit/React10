import React, { useState, useEffect } from 'react';

const PropertyDetails = ({ property, onRemove }) => {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate fetching data with a setTimeout
    
    return () => {
      
      // Log cleanup message when component unmounts
    };
  }, [property.id]);

  return (
    <div style={{ border: '1px solid black', padding: '10px', margin: '10px' }}>
      {/*     Simulate loading and display properties 
 */}
    </div>
  );
};

export default PropertyDetails;
