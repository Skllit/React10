import { useEffect } from 'react';

const PropertyMarker = ({ position, map, marker, onRemove }) => {
    
      // Attach click event listener to the marker
      
        // Remove the marker from the map

        // Call the onRemove function when marker is clicked
        
    

    // Clean up function to remove event listeners when component unmounts
    
      
        // Remove event listener to prevent memory leaks
        
    
  

  return null; // Marker doesn't render anything visible
};

export default PropertyMarker;
