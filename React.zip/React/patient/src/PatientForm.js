import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './App.css';
const PatientForm = () => {
  const [formData, setFormData] = useState({
    name: '',
    dob: '',
    medicalHistory: '',
    currentMedications: '',
  });

  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
    setErrors({ ...errors, [name]: '' }); // Clear the error when user starts typing
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // validate form data if form is valid than navigate to welcome page
  };

  const validate = (data) => {
    const errors = {};
    // add validation rules 
    return errors;
  };

  return (
    <div className="form-container">
      <h1>Patient Registration</h1>
     {/* Create Patient Form */}
    </div>
  );
};

export default PatientForm;
