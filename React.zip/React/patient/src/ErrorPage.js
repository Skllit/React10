// ErrorPage.js

import React from 'react';

const ErrorPage = () => {
// disply error messge in h1
};

export default ErrorPage;
