// WelcomePage.js

import React from 'react';

const WelcomePage = () => {
// display welcome message in h1
};

export default WelcomePage;
