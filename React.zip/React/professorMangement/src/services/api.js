import environment from "../environments/environment.ts"
const apiUrl = environment.apiUrl;

export const ProfessorServices = {
  getProfessors: async () => {
    // get professors from json server
  },

  addProfessor: async (professorData) => {
    // post data to db.json
  },
};