import { useState, useEffect } from 'react';
import { ProfessorServices } from '../services/api';
// import { Pro } from '../services/api';
const useProfessors = () => {
  
};


export default useProfessors;
