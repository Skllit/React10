import React from 'react';

// cimport React from 'react';
import '../App.css';

const ProfessorDetails = ({ professor }) => {
//  display professor detials 
};

export default ProfessorDetails;
