// AddProfessorForm.js
import React, { useEffect, useState } from "react";
import { ProfessorServices } from "../services/api";
import ProfessorDetails from "./ProfessorDetails";
import "../App.css";

function AddProfessorForm({ onSubmit }) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [errors, setErrors] = useState({});
  const [professors, setProfessors] = useState([]);


  const fetchProfessors = async () => {
    // fetch profeesors from json server
  };

//   use react hook to load professors 

  const validateForm = () => {
    // form validation 
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    // validate form and post data to json server
  };

  return (
    <div className="container">
     {/* professor form to add professor  */}
      <hr />
      {/* loop through professor and load professor detail component */}
    </div>
  );
}

export default AddProfessorForm;
