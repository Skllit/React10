import environment from './environments/environment.ts'
const API_URL = `${environment.apiUrl}/properties`;
// use API_URL
export const PropertyService = {
  getAllProperties: async () => {
  //  get all properties from json server
  },
  getPropertyByID: async (propertyID) => {
    // get property By id from json server
  },
  addProperty: async (newProperty) => {
    // add New property by using post call 
  }
};