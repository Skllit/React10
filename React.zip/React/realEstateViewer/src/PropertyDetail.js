import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import PropertyService from './PropertyService';
import './App.css'; // Import the CSS file

const PropertyDetail = () => {
  const { propertyID } = useParams();

  const [property, setProperty] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    // fetch property using Property Services 
  }, [propertyID]);

//   check for loading and errors while loading 

  return (
    <div className="property-detail-container">
      <h2>Property Details</h2>
      {/* display Property Attributes */}
    </div>
  );
};

export default PropertyDetail;
